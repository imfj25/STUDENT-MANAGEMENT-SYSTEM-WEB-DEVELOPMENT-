<div class="row" id="r3" style="background-color:#ddcc33">
    <div class="col-md-12">
      <div class="footer-copyright text-center py-3"  style="font-size:20px" >
                                  © Copyright @ 2022: Student management system || All Right Reserved. 
                                     </div>
    </div>
   </div>
