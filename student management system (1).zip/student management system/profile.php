<?php
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>profile</title>
<style>

</style>
</head>

<body>
<div class="container-fluids" id="con">
 <?php
 include("header.php");
 ?>      
            
        <div class="col-md-10 ">
        <h2>Student Profile</h2>
        
   <?php
   if(isset($_GET['id']))
   {
   $sql="select * from registration where id='".$_GET['id']."'";
   $query=mysqli_query($con,$sql);
  $dr=mysqli_fetch_array($query);
  }
  ?>
  <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
<div class="media">
<div class="media-left">
<img src="image/<?php echo $dr["photo"]?>" style="height:200px;width:200px;"/>
</div>
<div class="media-body">
<div class="form-group col-sm-6 ">
<label>Name:</label>
<input type="hidden" value="<?php echo $dr["id"] ?>" name="id"/>
<input type="text" value="<?php echo $dr["name"] ?>" class="form-control" name="name"/>
</div>
<div class="form-group col-sm-6">
<label>Registration no:</label>
<input type="text" value="<?php echo $dr["reg"] ?>" class="form-control" name="reg"/>
</div>

<div class="form-group">
<label>Roll no:</label>
<input type="text" value="<?php echo $dr["rno"] ?>" class="form-control" name="rno"/>
</div>

<div class="form-group">
<label>Email:</label>
<input type="text" value="<?php echo $dr["email"] ?>" class="form-control" name="email"/>
</div>


<div class="form-group">
<label>Mobile no:</label>
<input type="text" value="<?php echo $dr["mobile"] ?>" class="form-control" name="mobile"/>
</div>

<div class="form-group">
<label>Department:</label>
<input type="text" value="<?php echo $dr["department"] ?>" class="form-control" name="depart"/>
</div>

<button class="btn btn-primary" name="update">update</button>
</div>

</div>

</form>
<?php
if(isset($_POST['id']))
{
if(isset($_POST['update']))
{
  $sql="update registration set name='".$_POST['name']."',reg='".$_POST['reg']."',rno='".$_POST['rno']."',mobile='".$_POST['mobile']."',department='".$_POST['depart']."' where id='".$_POST['id']."'";
  if(mysqli_query($con,$sql))
  {
  echo "<script>window.location.href='afterupdate.php?id=".$_POST['id']."'</script>";
  }
}
}
?>

           
   </div>     
        </div>

<?php
include("footer.php");
?>
</div>
</body>
</html>