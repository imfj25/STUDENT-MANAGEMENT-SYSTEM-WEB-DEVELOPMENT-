 <div class="row " id="r1" >
    <div class="col-md-12" >
      <div class="media">
                               <div class="media-left">
                               <a href="#">
                              <img src="image/logo.png" class="media-object img-circle" style="width:100px;height:90px;">
                           </a> </div>
                                 <div class="media-body" >
                                  <h5 style="font-size:20px;font-family:Georgia, 'Times New Roman', Times, serif">STUDENT</h5>
                                  <h5 style="font-family:Georgia, 'Times New Roman', Times, serif">MANAGEMNET</h5>
                                  <h5 style="font-family:Georgia, 'Times New Roman', Times, serif"> SYSTEM</h5>
                                </div>
                              </div>
                              </div>
                              
                              
                        </div>      

                              
                         <div class="row " id="r2" >
    <div class="col-md-2" style="height:500px;margin-right:auto;border-right:solid">
                            
                              <ul class="nav navbar-stacked" >
      <li class="active"><a href="menu.php">Home</a></li>
      <li><a href="adduser.php">Add user</a></li>
      <li><a href="showinfo.php">Student Profile</a></li>
      <li><a href="registerform.php">Register form</a></li>
      <li><a href="#">Results</a></li>
     <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="">Attendance
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
        <li><a href="showattendence.php">show attendance</a></li>
        <li><a href="fillattendance.php">fill attendance</a></li>
        </ul>
      </li>
     
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Setting
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="changepassword.php">Change password</a></li>
          </ul>
      </li>
      <li><a href="contactus.php">Contact us</a></li>
     <li><a href="index.php">logout</a></li>
    </ul> 
   </div>
 

