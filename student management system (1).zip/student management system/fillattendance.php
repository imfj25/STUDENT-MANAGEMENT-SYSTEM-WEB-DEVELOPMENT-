<?php
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>fill attendance</title>
</head>

<body>
<div class="container-fluid">
  <?php
  include("header.php");
  ?>
        
            
        <div class="col-md-10 ">
           <h2 align="center" style="font-size:24px;color:#FF0000"> Student attandence</h2>
     <?php
	
			   if(isset($_POST["sub"]))
  {
  $sql="insert into attendence (reg,sname,date,attendence,rno,dept) values('".$_POST["reg"]."','".$_POST["sname"]."','".$_POST["date"]."','".$_POST["attendance"]."','".$_POST["rno"]."','".$_POST["dept"]."')";
  if(mysqli_query($con,$sql))
  {
  echo "<script>alert('details added')</script>";
  }
  else
  {
  echo "error".mysqli_error($con);
  }
 }
 
		?>
 

           <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
    <div class="form-group col-xs-6">
      <label >Registration no:</label>
      <input type="text" class="form-control" placeholder="Enter no"  id="reg" name="reg">
    </div>
     <div class="form-group col-xs-6">
      <label >Student Name:</label>
      <input type="text" class="form-control" placeholder="Enter name" id="name" name="sname">
    </div>
    <div class="form-group col-xs-6">
      <label >Roll no:</label>
      <input type="text" class="form-control" placeholder="Enter rno" id="rno" name="rno">
    </div>
    <div class="form-group col-xs-6">
    <label >Date:</label>
      <input type="text" class="form-control"  placeholder="Enter date" id="date" name="date">

    </div>
    
  <div class="form-group col-xs-6">
      <label >attendence</label>
      <select class="form-control" id="dept" placeholder="Select attendance" name="attendance">
        <option>Select attendence</option>
        <option>Present</option>
        <option>Absent</option>
        </select>
    </div>

    <div class="form-group col-xs-6">
      <label >Departments:</label>
      <select class="form-control" id="dept" placeholder="Select qlify" name="dept">
        <option>Select departments</option>
        <option>cse</option>
        <option>it</option>
        <option>ece</option>
        <option>ce</option>
        <option>me</option>
        <option>ee</option>
        <option>aa</option>
        <option>pe</option>
        <option>d. pharma</option>
        </select>
    </div>

                <button type="submit" class="btn btn-danger col-xs-3" style="font-size:16px">Cancel</button>
         <button type="submit" class="btn btn-success col-xs-3" name="sub" style="font-size:16px">Submit</button>
        
  </form>
</div>
       </div>
        </div>
        
   </div>     
        
<?php
include("footer.php");
?>

</div>
</body>
</html>
