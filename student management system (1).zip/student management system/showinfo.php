<?php
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>showdata</title>
<style></style>
</head>

<body>
<div class="container-fluid">
<?php
include("header.php");
?> 
  <div class="col-md-10">
  <!-- Left-aligned media object -->


<h2>
All informtion
</h2>
     <table class="table" style="width:100%">
  <tr>
    <th>Name</th>
    <th>Registration no.</th> 
    <th>Roll no.</th>
    <th>email</th>
    <th>dob</th>
    <th>mobile</th>
    <th>gender</th>
    <th>fname</th>
    <th>mname</th>
    <th>address</th>
    <th>session</th>
    <th>qualification</th>
    <th>department</th>
    <th>category</th>
    <th>
    Edit
    </th>
  </tr>
  <tr>
   <?php
   $sql="select * from registration";
   $query=mysqli_query($con,$sql);
   while($dr=mysqli_fetch_array($query))
 
   {
   ?>
  <tr>
   
    <td><?php echo $dr["name"] ?></td>
    <td><?php echo $dr["reg"] ?></td>
    <td><?php echo $dr["rno"] ?></td>
   <td><?php echo $dr["email"] ?></td>
    <td><?php echo $dr["dob"] ?></td>
    <td><?php echo $dr["mobile"] ?></td>
    <td><?php echo $dr["gender"] ?></td>
    <td><?php echo $dr["fname"] ?></td>
    <td><?php echo $dr["mname"] ?></td>
    <td><?php echo $dr["address"] ?></td>
    <td><?php echo $dr["session"] ?></td>
    <td><?php echo $dr["category"] ?></td>
    <td><?php echo $dr["qualification"] ?></td>
    <td><?php echo $dr["department"] ?></td>
    <td>
    <a href="profile.php?id=<?php echo $dr["id"] ?>">edit</a>
    </td>
    </tr>
  <?php
  }
  ?>
</table>
</div>
  </div> 
 </div>
 
 
  </div>
  <?php
  include("footer.php");
  ?>
</div>
</body>
</html>
