<?php
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>register form</title>
<style>

</style>
</head>

<body>
<div class="container-fluids" id="con">
  <?php
  include("header.php");
  ?>
           <div class="container" style="padding-left:40px;">    
        <div class="col-md-10 ">
        <?php
		       if(isset($_POST["sub"]))
  {
  $filename=$_FILES['file']['name'];
  $path="image/".$filename;
  $tmp=$_FILES['file']['tmp_name'];
  $sql="insert into registration (reg,name,email,dob,mobile,rno,gender,fname,mname,address,session,category,qualification,department,photo) values('".$_POST["reg"]."','".$_POST["name"]."','".$_POST["email"]."','".$_POST["dob"]."','".$_POST["mobile"]."','".$_POST["rno"]."','".$_POST["gender"]."','".$_POST["fname"]."','".$_POST["mname"]."','".$_POST["address"]."','".$_POST["session"]."','".$_POST["category"]."','".$_POST["qualification"]."','".$_POST["department"]."','".$filename."')";
  if(mysqli_query($con,$sql))
  {
  move_uploaded_file($tmp,$path);
  echo "<script>alert('details added')</script>";
  }
  else
  {
  echo "error".mysqli_error($con);
  }
 }
		?>
 
           <h2 align="center" style="font-size:24px;color:#FF0000"> Student Registration</h2>
           

           <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
    
    
          <div id="image-preview-div" style="display: none">
            <label for="exampleInputFile">Selected image:</label>
           
          </div>
          <div class="form-group">
            <input type="file" name="file" id="file" required>
          </div>
          
        

    
    
    <div class="form-group col-xs-6">
      <label >Registration no:</label>
      <input type="text" class="form-control" placeholder="Enter reg no" id="name" name="reg">
    </div>
         <div class="form-group col-xs-6">
      <label >Student Name:</label>
      <input type="text" class="form-control" placeholder="Enter name" id="name" name="name" >
    </div>
    <div class="form-group col-xs-6">
      <label >Email id:</label>
      <input type="email" class="form-control" placeholder="Enter email" id="email" name="email" >
    </div>
      <div class="form-group col-xs-6 " >
    <label >D O B:</label>
      <input type="date" class="form-control"  placeholder="Enter dob" id="dob" name="dob" >
    </div> 
      <div class="form-group col-xs-3">
    <label >Mobile:</label>
      <input type="text" class="form-control"  placeholder="Enter number" id="mobile" name="mobile" >
    </div>
     <div class="form-group col-xs-3">
    <label>Roll no:</label>
      <input type="text" class="form-control"  placeholder="Enter Roll no" id="rno" name="rno" >
    </div>
    
      <div class="form-group col-xs-6">
       <label >Gender:</label>
    <div class="radio">
      <label><input type="radio" name="gender"
      <?php if (isset($gender) && $gender=="male") echo "checked";?>
value="male" >Male</label>
      
      <label><input type="radio" name="gender"
       <?php if (isset($gender) && $gender=="female") echo "checked";?>
value="female">Female</label>
    </div>
      </div>
      
    <div class="form-group col-xs-6">
    <label>Father name:</label>
      <input type="text" class="form-control"  placeholder="Enter Name" id="fname" name="fname" >
    </div>
    <div class="form-group col-xs-6" >
    <label>Mother name:</label>
      <input type="text" class="form-control"  placeholder="Enter name" id="mname" name="mname" >
    </div>
      <div class="form-group col-xs-12">
    <label >Address:</label>
      <input type="text" class="form-control"  placeholder="Enter name" id="Add" name="address" >
    </div>
      <div class="form-group col-xs-12">
    <label >Session:</label>
      <input type="text" class="form-control"  placeholder="Enter Session" id="session" name="session" >
    </div>
    
    <div class="form-group col-xs-12">
      <label >Category:</label>
      <select class="form-control" id="dept" placeholder="Select category" name="category" >
        <option>Select Category</option>
        <option>General</option>
        <option>Sc</option>
        <option>Bc</option>
        </select>
    </div>
    <div class="form-group col-xs-12">
      <label >Qualification:</label>
      <select class="form-control" id="dept" placeholder="Select qlify" name="qualification">
        <option>Select qulification</option>
        <option>10th</option>
        <option>12th</option>
        <option>ITI</option>
        </select>
    </div>
    <div class="form-group col-xs-12">
      <label >Departments:</label>
      <select class="form-control" id="dept" placeholder="Select qlify" name="department">
        <option>Select departments</option>
        <option>cse</option>
        <option>it</option>
        <option>ece</option>
        <option>ce</option>
        <option>me</option>
        <option>ee</option>
        <option>aa</option>
        <option>pe</option>
        <option>d. pharma</option>
        </select>
    </div>

                <button type="submit" class="btn btn-danger col-xs-3" style="font-size:16px">Cancel</button>
         <button type="submit" class="btn btn-success col-xs-3" style="font-size:16px" name="sub">Submit</button>
        
  </form>
</div>
       </div>
        </div>
        
   </div>     
        
<?php
  include("footer.php");
  ?>
  
</div>
</body>
</html>