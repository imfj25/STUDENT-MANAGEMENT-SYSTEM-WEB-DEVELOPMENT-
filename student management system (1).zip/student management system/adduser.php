<?php
include("connection.php")


  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Add user</title>
<style>

</style>
</head>
   

<body>
 <div class="container-fluids" id="con">
 <?php
 include("header.php");
 ?>
        
         <div class="container ">
         <div class="row " id="r2"> 
                 
             <div class="col-md-10" >
                        <h2 align="center">Add user</h2>
						<?php
	
			   if(isset($_POST["sub"]))
  {
  $sql="insert into login (email,password) values('".$_POST["email"]."','".$_POST["pwd"]."')";
  if(mysqli_query($con,$sql))
  {
  echo "<script>alert('details added')</script>";
  }
  else
  {
  echo "error".mysqli_error($con);
  }
 }
 
		?>
 
                <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" >
  
   
  <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
    
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
    </div>
    
    
    <button type="submit" class="btn btn-info" name="sub" >Add user</button>
</form>
              </div>
            </div>
         </div>
  <?php
  include("footer.php")
  ?>
        
    
     
 </div>
</body>
</html>
