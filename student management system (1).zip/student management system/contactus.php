<?php
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title> customer feedback</title>

<style>
#r7 h1{
font-weight:bold;
}
</style>
</head>

<body>

 <div class="container-fluid" id="con">
 <?php
 include("header.php");
 ?>
 <div class="container">
  <div class="row" id="r7">
   <div class="col-md-10 text-center">
     <h1 style="color:#FF0000"> Got a Question ?</h1>
     <p > Chat with us - OptiMonster team is here to help <br />you boost your conversions. </p>
    
  <div class="row" id="r2">
  <?php
  if(isset($_POST["sub"]))
  {
  $sql="insert into contactus (name,email,interest,description) values('".$_POST["name"]."','".$_POST["email"]."','".$_POST["interest"]."',
  '".$_POST["description"]."')";
  if(mysqli_query($con,$sql))
  {
  echo "<script>alert('details added')</script>";
  }
  else
  {
  echo "error".mysqli_error($con);
  }
 }
  ?>
  <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
     <div class="form-group">
  <input type="text" class="form-control" name="name" id="usr" placeholder="Your Name">
</div>
       <div class="form-group">
    <input type="email" type="text" class="form-control" name="email" id="email" placeholder=" Your Email">
  </div>
       <div class="form-group">
   <textarea class="form-control"   name="interest" id="interest" placeholder=" interest"></textarea>
  </div>
      <div class="form-group">
   <textarea class="form-control" rows="5" name="description" id="comment" placeholder=" Type in your question"></textarea>
  </div>
      <button type="submit"  name="sub" class="btn btn-info" style="background-color:#FF6600;color:#FFFFFF" > Send Your Message</button>
      </form>
      </div>
      
         </div>
         </div>
         </div>
         <?php
		 include("footer.php");
		 ?>
         
 </div>
</body>
</html>
