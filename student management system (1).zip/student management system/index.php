<?php
include("connection.php")


  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>index</title>
<style>

</style>
</head>
   

<body>
 <div class="container-fluids" id="con">
  <div class="row" id="r1" style="background-color:#ddcc33">
    <div class="col-md-8">
       <div class="media">
                               <div class="media-left">
                               <a href="index.html">
                              <img src="image/logo.png" class="media-object img-circle" style="width:100px;height:90px;">
                           </a> </div>
                                 <div class="media-body" >
                                  <h5 style="font-size:20px;font-family:Georgia, 'Times New Roman', Times, serif">STUDENT</h5>
                                  <h5 style="font-family:Georgia, 'Times New Roman', Times, serif">MANAGEMNET</h5>
                                  <h5 style="font-family:Georgia, 'Times New Roman', Times, serif"> SYSTEM</h5>
                                </div>
                              </div>
                              
                              </div>
                           
       </div>
         
         <div class="container ">
         <div class="row " id="r2"> 
                 
             <div class="col-md-12" >
                        <h2 align="center">Admin Log In</h2>
						<?php
						if(isset($_POST['login']))
						{
						$sql="select * from login where email='".$_POST['email']."' and password='".$_POST['pwd']."'";
						$query=mysqli_query($con,$sql);
						if(mysqli_num_rows($query)>0)
						{
						session_start();
						$_SESSION['email']=$_POST['email'];
						echo "<script>window.location.href='menu.php'</script>";
						}
						else
						{
						echo "error".mysqli_error($con);
						}
						}
						?>
                <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" >
  
     
  <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
    
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
    </div>
    <button type="submit" class="btn btn-info " name="login" >log in</button>
</form>
              </div>
            </div>
         </div>
  <?php
  include("footer.php")
  ?>
        
    
     
 </div>
</body>
</html>
